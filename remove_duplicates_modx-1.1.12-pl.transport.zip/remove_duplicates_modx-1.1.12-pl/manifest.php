<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '18254bec4cc263135336189318bde379',
      'native_key' => 'remove_duplicates_modx',
      'filename' => 'modNamespace/1bf5a9aea06363271c79ed92d577db29.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0379b9bc8b61ac949ca673f6b6b94c31',
      'native_key' => 'Remove Duplicates MODX',
      'filename' => 'modMenu/1fe0ac9d9166df5be614167a44db80b0.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '560d6ad01b9ba8ae2e4d0526528a3ef8',
      'native_key' => NULL,
      'filename' => 'modCategory/4114deac5c76faae2979a741c23b0c5f.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
  ),
);