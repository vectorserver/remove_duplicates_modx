<?php
require_once (dirname(__DIR__) . '/remove_duplicates_modxgroup.class.php');
class remove_duplicates_modxGroup_mysql extends remove_duplicates_modxGroup {}