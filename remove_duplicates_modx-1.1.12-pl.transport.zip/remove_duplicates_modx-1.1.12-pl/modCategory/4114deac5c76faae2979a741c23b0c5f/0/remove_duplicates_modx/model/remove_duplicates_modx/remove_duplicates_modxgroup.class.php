<?php
class remove_duplicates_modxGroup extends xPDOSimpleObject {}