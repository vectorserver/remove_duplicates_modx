<?php
require_once (dirname(__DIR__) . '/remove_duplicates_modxitem.class.php');
class remove_duplicates_modxItem_mysql extends remove_duplicates_modxItem {}