<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'remove_duplicates_modxGroup',
    1 => 'remove_duplicates_modxItem',
  ),
);