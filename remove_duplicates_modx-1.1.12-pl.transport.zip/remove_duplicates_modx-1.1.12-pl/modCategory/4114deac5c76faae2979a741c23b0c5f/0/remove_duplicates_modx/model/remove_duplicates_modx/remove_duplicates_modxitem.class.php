<?php
class remove_duplicates_modxItem extends xPDOSimpleObject {}