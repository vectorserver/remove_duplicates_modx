<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a965edf5d8303a4c688e57c486f90840',
      'native_key' => 'remove_duplicates_modx',
      'filename' => 'modNamespace/357ab300514595a91840db27f7e1ddcd.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c183f8ceb9c604d52720afea593f2c83',
      'native_key' => 'Remove Duplicates MODX',
      'filename' => 'modMenu/3a8d0eb8243135b98f72ae6eef9e367a.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '31c1847e951714e15c575c8048377bdc',
      'native_key' => NULL,
      'filename' => 'modCategory/17377352181c59739becbd550c5de384.vehicle',
      'namespace' => 'remove_duplicates_modx',
    ),
  ),
);